---
name: personalens
description: Test fixture. The real PersonaLens skill is proprietary and not published in this repository.
---

# PersonaLens (test fixture)

This file stands in for the PersonaLens skill so the installer tests have a real package to install.
