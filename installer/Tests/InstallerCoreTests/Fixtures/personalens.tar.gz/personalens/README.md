# PersonaLens — the installable package

This directory is what "Install → Claude / ChatGPT / Kimi" distributes: the PersonaLens capability
packaged in the Agent Plugins layout (root `plugin.json`, skills under `skills/`), so one package
serves every compatible client.

- The **skill** (`skills/personalens/SKILL.md`) carries the product's method: build persona agents
  from client records, simulate a strategic move, return opinion + satisfaction per segment,
  compare directions.
- The **full product** (web app with grounded market research, persona vote and decision judge)
  lives in the separate PersonaLens repository; this package is the workspace-native distribution
  of the same method.
- Before first public release, verify the manifest fields against the current Agent Plugins
  specification; this layout follows the published convention as of September 2026.
